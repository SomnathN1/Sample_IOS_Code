//
//  Constants.h
//  SampleApp
//
//

#ifndef Constants_h
#define Constants_h

#define invalidCredentialsAlert @"Please enter valid email id and password"
#define emptyCredentialsAlert @"Email or Password cannot be blank"
#define loginSuccessAlert @"Login successful"

#endif /* Constants_h */
