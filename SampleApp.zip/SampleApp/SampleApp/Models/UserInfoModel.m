//
//  UserInfoModel.m
//  SampleApp
//
//

#import "UserInfoModel.h"
#import "Utility.h"

@implementation UserInfoModel

-(id)initWithCoder:(NSCoder *)aDecoder
{
    if(self = [super init])
    {
        [self setUserId:[aDecoder decodeObjectForKey:userIdKey]];
        [self setUserType:[aDecoder decodeObjectForKey:userTypeKey]];
        [self setUserEmailId:[aDecoder decodeObjectForKey:userEmailIdKey]];
        [self setUserFirstName:[aDecoder decodeObjectForKey:userFirstNameKey]];
        [self setUserLastName:[aDecoder decodeObjectForKey:userLastNameKey]];
    }
    return self;
}

-(void)encodeWithCoder:(NSCoder *)aCoder
{
    [aCoder encodeObject:_userId forKey:userIdKey];
    [aCoder encodeObject:_userType forKey:userTypeKey];
    [aCoder encodeObject:_userEmailId forKey:userEmailIdKey];
    [aCoder encodeObject:_userFirstName forKey:userFirstNameKey];
    [aCoder encodeObject:_userLastName forKey:userLastNameKey];
}

-(NSString *)getUserName
{
    NSString *username = @"";
    
    if([Utility checkIfStringContainsText:_userFirstName])
        username = [NSString stringWithFormat:@"%@ ",_userFirstName];
    if([Utility checkIfStringContainsText:_userLastName])
        username = [NSString stringWithFormat:@"%@%@ ",username,_userLastName];
    
    return username;
}

@end
