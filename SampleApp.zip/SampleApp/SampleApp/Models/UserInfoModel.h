//
//  UserInfoModel.h
//  SampleApp
//
//

#import <Foundation/Foundation.h>

#define userIdKey @"userId"
#define userTypeKey @"userType"
#define userEmailIdKey @"userEmailId"
#define userFirstNameKey @"userFirstName"
#define userLastNameKey @"userLastName"

@interface UserInfoModel : NSObject

@property (nonatomic, strong) NSString *userId;
@property (nonatomic, strong) NSString *userType;
@property (nonatomic, strong) NSString *userEmailId;
@property (nonatomic, strong) NSString *userFirstName;
@property (nonatomic, strong) NSString *userLastName;

-(NSString *)getUserName;

@end
