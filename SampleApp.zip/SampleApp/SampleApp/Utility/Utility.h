//
//  Utility.h
//
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface Utility : NSObject{
    
}

+(BOOL)checkIfStringContainsText:(NSString *)string;

+(NSString *)getStringFromChar:(char const *)characterString;

+(void)showUnderDevelopmentAlert;

+(void)addBasicConstraintsOnSubView:(UIView *)subView onSuperView:(UIView *)superView;

+(BOOL)validateEmail:(NSString *)emailStr;

+(BOOL)validateUrl:(NSString *)candidate;

+(void)showAlert:(NSString *)title withMessage:(NSString *)message delegate:(id)delegate;


@end