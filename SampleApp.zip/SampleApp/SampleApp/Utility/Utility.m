//
//  NSIUtility.m
//  VideoHotspot
//
//  Created by Aditya Aggarwal on 12/02/14.
//  Copyright (c) 2014 Net Solutions. All rights reserved.
//

#import "Utility.h"
#import <UIKit/UIKit.h>

@implementation Utility

+(BOOL)checkIfStringContainsText:(NSString *)string
{
    if(!string || string == NULL || [string isEqual:[NSNull null]])
        return FALSE;
    
    NSString *newString = [string stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    if([newString isEqualToString:@""])
        return FALSE;
    
    return TRUE;
}

+(NSString *)getStringFromChar:(char const *)characterString
{
    if(!characterString || characterString == NULL)
        return nil;
    
    return [NSString stringWithUTF8String:characterString];
}

+(void)showUnderDevelopmentAlert
{
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Under Development!" message:@"This feature is under development and will be available in future releases." delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
    [alertView show];
}

+(void)addBasicConstraintsOnSubView:(UIView *)subView onSuperView:(UIView *)superView
{
    [subView setTranslatesAutoresizingMaskIntoConstraints:NO];
    [superView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:[NSString stringWithFormat:@"V:|-%f-[subView]-%f-|",subView.frame.origin.y,subView.frame.origin.y] options: NSLayoutFormatAlignmentMask metrics:nil views:NSDictionaryOfVariableBindings(subView)]];
    [superView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:[NSString stringWithFormat:@"|-%f-[subView]-%f-|",subView.frame.origin.x,subView.frame.origin.x] options: NSLayoutFormatAlignmentMask metrics:nil views:NSDictionaryOfVariableBindings(subView)]];
}

+ (BOOL)validateEmail:(NSString *)emailStr {
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:emailStr];
}

+ (BOOL)validateUrl: (NSString *) candidate {
    NSString *urlRegExHttp =
    @"(http|https)://((\\w)*|([0-9]*)|([-|_])*)+([\\.|/]((\\w)*|([0-9]*)|([-|_])*))+";
    NSString *urlRegExWWW =
    @"www.+[a-z]+\\.[a-z]{2,4}";
    
    NSPredicate *urlTestHttp = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", urlRegExHttp];
    NSPredicate *urlTestWWW = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", urlRegExWWW];
    
    return [urlTestHttp evaluateWithObject:candidate] || [urlTestWWW evaluateWithObject:candidate];
}

+(void)showAlert:(NSString *)title withMessage:(NSString *)message delegate:(id)delegate
{
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:title message:message delegate:delegate cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [alertView show];
}

+(void)addSubview:(UIView *)subview withFadeInAnimationOnSuperView:(UIView *)superview
{
    if(!subview || !superview)
        return;
    
    [subview setAlpha:0.0];
    [superview addSubview:subview];
    
    [UIView animateWithDuration:0.3 animations:^{
        [subview setAlpha:1.0];
    }];
}

+(void)removeSubviewWithFadeOutAnimation:(UIView *)subview
{
    if(!subview || ![subview superview])
        return;
    
    [subview setAlpha:1.0];
    
    [UIView animateWithDuration:0.3 animations:^{
        [subview setAlpha:0.0];
    } completion:^(BOOL finished) {
        [subview removeFromSuperview];
    }];
}


@end