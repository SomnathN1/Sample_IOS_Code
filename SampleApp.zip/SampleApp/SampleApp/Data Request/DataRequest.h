//
//  dataRequest.h
//
//

#import <Foundation/Foundation.h>

@interface DataRequest : NSObject

- (void)fetchFrom:(NSURL *)url
        onSuccess:(void(^)(id response))successBlock
        onFailure:(void(^)(NSError * error)) failureBlock;

- (void)everyTenthLetterFromURL:(NSURL *) url
                      onSuccess:(void(^)(NSArray *letters))success
                      onFailure:(void (^)(NSError *error))failureBlock;

- (void)fifthLetterFromURL:(NSURL *) url
                 onSuccess:(void(^)(NSString *letter))success
                 onFailure:(void (^)(NSError *error))failureBlock;

-(void) allWordsFromURL:(NSURL *)url
              onSuccess:(void (^)(NSArray *words))success
              onFailure:(void (^)(NSError *error))failureBlock;
@end
