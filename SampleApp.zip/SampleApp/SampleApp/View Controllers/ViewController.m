//
//  ViewController.m
//  SampleApp
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

#pragma mark - View Lifecycle
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    [self setupDelegate];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

// Setup text fied delegates
- (void)setupDelegate {
    emailTextField.delegate = self;
    pwdTextField.delegate = self;
}

#pragma mark - IBAction methods
- (IBAction)loginButtonTapped:(id)sender {
    if([Utility checkIfStringContainsText:emailTextField.text] && [Utility checkIfStringContainsText:pwdTextField.text]) {
        if([Utility validateEmail:emailTextField.text]) {
            // Login successful
            [self performSegueWithIdentifier:@"DashboardIdentifier" sender:self];
        }
        else {
            [Utility showAlert:@"" withMessage:invalidCredentialsAlert delegate:self];
        }
    }
    else {
        [Utility showAlert:@"" withMessage:emptyCredentialsAlert delegate:self];
    }
}

#pragma mark - UITextfield delegate
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    if (textField == emailTextField) {
        [pwdTextField becomeFirstResponder];
    }else
        [textField resignFirstResponder];
    
    return YES;
}

@end
