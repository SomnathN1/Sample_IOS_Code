//
//  DashboardViewController.h
//
//

#import <UIKit/UIKit.h>
#import "DataRequest.h"
#import "Utility.h"

@interface DashboardViewController : UIViewController {
    // IBOutlet properties
    __weak IBOutlet UITextView *firstTextView;
    __weak IBOutlet UITextView *letterTextView;
    __weak IBOutlet UITextView *countTextView;
}

// IBAction methods
- (IBAction)runButtonTapped:(id)sender;

@end
