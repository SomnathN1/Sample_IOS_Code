//
//  ViewController.h
//  SampleApp
//

// Login screen to validate and authenticate user

#import <UIKit/UIKit.h>
#import "Utility.h"
#import "Constants.h"

@interface ViewController : UIViewController<UITextFieldDelegate> {
    // IBOutlet properties
    __weak IBOutlet UITextField *emailTextField;
    __weak IBOutlet UITextField *pwdTextField;
    __weak IBOutlet UIButton *loginButton;
}

// IBAction methods
- (IBAction)loginButtonTapped:(id)sender;

@end

