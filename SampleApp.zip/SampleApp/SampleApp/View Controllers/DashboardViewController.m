//
//  DashboardViewController.m
//
//

#import "DashboardViewController.h"

@interface DashboardViewController ()

@end

@implementation DashboardViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

// Run requests
- (IBAction)runButtonTapped:(id)sender {
    NSURL *url = [NSURL URLWithString:@"https://www.google.com/"];
    NSString *wordToCount = @"google";
    
    DataRequest *request = [[DataRequest alloc] init];
    // It will print fifth Letter from Url reponse string
    [request fifthLetterFromURL:url
                      onSuccess:^(NSString* letter) {
                          [firstTextView setText:letter];
                      } onFailure:^(NSError* error) {
                          [Utility showAlert:@"" withMessage:[error localizedDescription] delegate:self];
                      }];
    
    [request everyTenthLetterFromURL:url
                           onSuccess:^(NSArray * letters){
                               [letterTextView setText: [letters componentsJoinedByString:@""]];
                           } onFailure:^(NSError * error) {
                               [Utility showAlert:@"" withMessage:[error localizedDescription] delegate:self];
                           }];
    
    
    [request  allWordsFromURL:url
                    onSuccess:^(NSArray *words) {
                        __block NSUInteger count =0;
                        
                        [words enumerateObjectsUsingBlock:^(NSString *word, NSUInteger idx, BOOL *stop) {
                            if ([word compare:wordToCount options:NSCaseInsensitiveSearch]) {
                                ++count;
                            }
                        }];
                        [countTextView setText:[NSString stringWithFormat:@"\"%@\" was found %lu times in %lu words", wordToCount, (unsigned long)count, (unsigned long)[words count]]];
                        
                    } onFailure:^(NSError *error) {
                        [Utility showAlert:@"" withMessage:[error localizedDescription] delegate:self];
                    }];
}

@end
